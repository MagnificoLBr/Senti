
use anchor_lang::prelude::*;

#[account]
pub struct Vault {
	pub name: String,
	pub manager: Pubkey,
	pub delegate: Option<Pubkey>,
	pub fee_collector: Pubkey,
	pub share_mint: Pubkey,
	pub vault_usdc_ata: Pubkey,
	pub total_shares: u64,
	pub management_fee_bps: u16,
	pub profit_share_bps: u16,
	pub hurdle_rate_bps: u16,
	pub high_watermark: u64,
	pub redeem_period: u64,
	pub min_deposit_amount: u64,
	pub paused: bool,
	pub in_liquidation: bool,
	pub drift_user: Option<Pubkey>,
	pub drift_user_stats: Option<Pubkey>,
	pub last_fee_collection_ts: i64,
	pub bump: u8,
}
