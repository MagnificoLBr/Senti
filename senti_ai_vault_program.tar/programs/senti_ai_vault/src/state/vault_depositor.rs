
use anchor_lang::prelude::*;

#[account]
pub struct VaultDepositor {
	pub vault: Pubkey,
	pub user: Pubkey,
	pub shares: u64,
	pub last_action_ts: i64,
	pub bump: u8,
}
