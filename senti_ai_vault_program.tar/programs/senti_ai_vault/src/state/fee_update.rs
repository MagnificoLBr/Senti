
use anchor_lang::prelude::*;

#[account]
pub struct FeeUpdate {
	pub vault: Pubkey,
	pub new_management_fee_bps: u16,
	pub new_profit_share_bps: u16,
	pub new_hurdle_rate_bps: u16,
	pub update_ts: i64,
	pub timelock_period: u64,
	pub bump: u8,
}
