
use anchor_lang::prelude::*;

#[account]
pub struct WithdrawRequest {
	pub vault: Pubkey,
	pub user: Pubkey,
	pub shares: u64,
	pub value: u64,
	pub request_ts: i64,
	pub bump: u8,
}
