

use anchor_lang::prelude::*;

#[error_code]
pub enum SentiAiVaultError {
	#[msg("Unauthorized access")]
	Unauthorized,
	#[msg("Vault operations are paused")]
	VaultPaused,
	#[msg("Vault is in liquidation mode")]
	VaultInLiquidation,
	#[msg("Deposit amount below minimum")]
	InsufficientDeposit,
	#[msg("Insufficient shares for withdrawal")]
	InsufficientShares,
	#[msg("No pending withdrawal request found")]
	WithdrawRequestNotFound,
	#[msg("Withdrawal timelock period not met")]
	WithdrawTimelockNotMet,
	#[msg("Fee update timelock period not met")]
	FeeUpdateTimelockNotMet,
	#[msg("Invalid fee parameters provided")]
	InvalidFeeParameters,
	#[msg("No equity available for profit sharing")]
	NoEquityForProfitShare,
	#[msg("Invalid rebase parameters")]
	InvalidRebaseParameters,
	#[msg("Arithmetic operation failed")]
	ArithmeticError,
}
