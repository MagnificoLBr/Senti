use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
	new_management_fee_bps: u16,
	new_profit_share_bps: u16,
	new_hurdle_rate_bps: u16,
	timelock_period: u64,
)]
pub struct StartFeeUpdate<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	#[account(
		init,
		space=63,
		payer=fee_payer,
		seeds = [
			b"fee_update",
			vault.key().as_ref(),
		],
		bump,
	)]
	pub fee_update: Account<'info, FeeUpdate>,

	pub manager: Signer<'info>,

	pub system_program: Program<'info, System>,
}

/// Stage new fee parameters with timelock
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[]` vault: [Vault] The vault to update fees for
/// 2. `[writable]` fee_update: [FeeUpdate] Fee update staging account
/// 3. `[signer]` manager: [AccountInfo] Vault manager account
/// 4. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - new_management_fee_bps: [u16] New management fee in basis points
/// - new_profit_share_bps: [u16] New profit share fee in basis points
/// - new_hurdle_rate_bps: [u16] New hurdle rate in basis points
/// - timelock_period: [u64] Timelock period in seconds
pub fn handler(
	ctx: Context<StartFeeUpdate>,
	name: String,
	new_management_fee_bps: u16,
	new_profit_share_bps: u16,
	new_hurdle_rate_bps: u16,
	timelock_period: u64,
) -> Result<()> {
    // Implement your business logic here...
	
	Ok(())
}
