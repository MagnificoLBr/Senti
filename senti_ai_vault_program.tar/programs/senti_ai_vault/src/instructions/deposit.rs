use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
	amount: u64,
)]
pub struct Deposit<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		mut,
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	#[account(
		init_if_needed,
		space=89,
		payer=fee_payer,
		seeds = [
			b"vault_depositor",
			vault.key().as_ref(),
			user.key().as_ref(),
		],
		bump,
	)]
	pub vault_depositor: Account<'info, VaultDepositor>,

	pub user: Signer<'info>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub user_usdc_ata: UncheckedAccount<'info>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub vault_usdc_ata: UncheckedAccount<'info>,

	#[account(mut)]
	pub share_mint: Account<'info, Mint>,

	#[account(
		signer,
		init_if_needed,
		space=8,
		payer=fee_payer,
	)]
	/// CHECK: implement manual checks if needed
	pub user_share_ata: UncheckedAccount<'info>,

	pub system_program: Program<'info, System>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub source: UncheckedAccount<'info>,

	#[account(mut)]
	pub mint: Account<'info, Mint>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub destination: UncheckedAccount<'info>,

	pub authority: Signer<'info>,

	pub assoc_token_account: Account<'info, TokenAccount>,

	pub owner: Signer<'info>,

	/// CHECK: implement manual checks if needed
	pub wallet: UncheckedAccount<'info>,

	pub token_program: Program<'info, Token>,

	pub token_program: Program<'info, Token>,
}

impl<'info> Deposit<'info> {
	pub fn cpi_token_transfer_checked(&self, amount: u64, decimals: u8) -> Result<()> {
		anchor_spl::token::transfer_checked(
			CpiContext::new(self.token_program.to_account_info(), 
				anchor_spl::token::TransferChecked {
					from: self.source.to_account_info(),
					mint: self.mint.to_account_info(),
					to: self.destination.to_account_info(),
					authority: self.authority.to_account_info()
				}
			),
			amount, 
			decimals, 
		)
	}
	pub fn cpi_token_mint_to(&self, amount: u64) -> Result<()> {
		anchor_spl::token::mint_to(
			CpiContext::new(self.token_program.to_account_info(), 
				anchor_spl::token::MintTo {
					mint: self.mint.to_account_info(),
					to: self.assoc_token_account.to_account_info(),
					authority: self.owner.to_account_info()
				}
			),
			amount, 
		)
	}
}


/// User deposits USDC and receives vault shares pro-rata
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to deposit into
/// 2. `[writable]` vault_depositor: [VaultDepositor] User's depositor account
/// 3. `[signer]` user: [AccountInfo] The user making the deposit
/// 4. `[writable]` user_usdc_ata: [AccountInfo] User's USDC token account
/// 5. `[writable]` vault_usdc_ata: [AccountInfo] Vault's USDC token account
/// 6. `[writable]` share_mint: [Mint] Vault share mint
/// 7. `[writable, signer]` user_share_ata: [AccountInfo] User's share token account
/// 8. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
/// 9. `[writable]` source: [AccountInfo] The source account.
/// 10. `[writable]` mint: [Mint] The token mint.
/// 11. `[writable]` destination: [AccountInfo] The destination account.
/// 12. `[signer]` authority: [AccountInfo] The source account's owner/delegate.
/// 13. `[writable]` assoc_token_account: [Account] The account to mint tokens to.
/// 14. `[signer]` owner: [AccountInfo] The mint's minting authority.
/// 15. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 16. `[]` token_program: [AccountInfo] SPL Token program
/// 17. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - amount: [u64] Amount of USDC to deposit
pub fn handler(
	ctx: Context<Deposit>,
	name: String,
	amount: u64,
) -> Result<()> {
    // Implement your business logic here...
	
	// Cpi calls wrappers
	ctx.accounts.cpi_token_transfer_checked(
		Default::default(),
		Default::default(),
	)?;

	ctx.accounts.cpi_token_mint_to(
		Default::default(),
	)?;

	Ok(())
}
