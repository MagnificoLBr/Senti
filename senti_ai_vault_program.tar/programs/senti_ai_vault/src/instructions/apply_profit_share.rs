use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
	current_equity: u64,
)]
pub struct ApplyProfitShare<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		mut,
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	pub manager: Signer<'info>,

	#[account(mut)]
	pub share_mint: Account<'info, Mint>,

	#[account(
		signer,
		init_if_needed,
		space=8,
		payer=fee_payer,
	)]
	/// CHECK: implement manual checks if needed
	pub fee_collector_share_ata: UncheckedAccount<'info>,

	pub system_program: Program<'info, System>,

	#[account(mut)]
	pub mint: Account<'info, Mint>,

	pub assoc_token_account: Account<'info, TokenAccount>,

	pub owner: Signer<'info>,

	/// CHECK: implement manual checks if needed
	pub wallet: UncheckedAccount<'info>,

	pub token_program: Program<'info, Token>,

	pub token_program: Program<'info, Token>,
}

impl<'info> ApplyProfitShare<'info> {
	pub fn cpi_token_mint_to(&self, amount: u64) -> Result<()> {
		anchor_spl::token::mint_to(
			CpiContext::new(self.token_program.to_account_info(), 
				anchor_spl::token::MintTo {
					mint: self.mint.to_account_info(),
					to: self.assoc_token_account.to_account_info(),
					authority: self.owner.to_account_info()
				}
			),
			amount, 
		)
	}
}


/// Crystallize profit share vs high watermark and mint manager shares
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to apply profit share for
/// 2. `[signer]` manager: [AccountInfo] Vault manager account
/// 3. `[writable]` share_mint: [Mint] Vault share mint
/// 4. `[writable, signer]` fee_collector_share_ata: [AccountInfo] Fee collector's share token account
/// 5. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
/// 6. `[writable]` mint: [Mint] The mint.
/// 7. `[writable]` assoc_token_account: [Account] The account to mint tokens to.
/// 8. `[signer]` owner: [AccountInfo] The mint's minting authority.
/// 9. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 10. `[]` token_program: [AccountInfo] SPL Token program
/// 11. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - current_equity: [u64] Current vault equity value
pub fn handler(
	ctx: Context<ApplyProfitShare>,
	name: String,
	current_equity: u64,
) -> Result<()> {
    // Implement your business logic here...
	
	// Cpi calls wrappers
	ctx.accounts.cpi_token_mint_to(
		Default::default(),
	)?;

	Ok(())
}
