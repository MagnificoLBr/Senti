use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	fee_collector: Pubkey,
	name: String,
	management_fee_bps: u16,
	profit_share_bps: u16,
	hurdle_rate_bps: u16,
	redeem_period: u64,
	min_deposit_amount: u64,
)]
pub struct InitializeVault<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		init,
		space=320,
		payer=fee_payer,
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	pub manager: Signer<'info>,

	#[account(
		init,
		payer = fee_payer,
		mint::decimals = 0,
	)]
	pub share_mint: Account<'info, Mint>,

	#[account(
		signer,
		init,
		space=8,
		payer=fee_payer,
	)]
	/// CHECK: implement manual checks if needed
	pub vault_usdc_ata: UncheckedAccount<'info>,

	pub usdc_mint: Account<'info, Mint>,

	pub system_program: Program<'info, System>,

	#[account(mut)]
	pub mint: Account<'info, Mint>,

	#[account(
		mut,
		owner=Pubkey::from_str("11111111111111111111111111111111").unwrap(),
	)]
	pub funding: Signer<'info>,

	#[account(
		init,
		payer = funding,
		associated_token::mint = mint,
		associated_token::authority = wallet,
		associated_token::token_program = token_program,
	)]
	pub assoc_token_account: Account<'info, TokenAccount>,

	/// CHECK: implement manual checks if needed
	pub wallet: UncheckedAccount<'info>,

	pub token_program: Program<'info, Token>,

	pub token_program: Program<'info, Token>,

	pub associated_token_program: Program<'info, AssociatedToken>,
}

impl<'info> InitializeVault<'info> {
	pub fn cpi_token_initialize_mint2(&self, decimals: u8, mint_authority: Pubkey, freeze_authority: Option<Pubkey>) -> Result<()> {
		anchor_spl::token::initialize_mint2(
			CpiContext::new(self.token_program.to_account_info(), 
				anchor_spl::token::InitializeMint2 {
					mint: self.mint.to_account_info()
				}
			),
			decimals, 
			mint_authority, 
			freeze_authority, 
		)
	}
}


/// Creates a new vault with share mint and USDC ATA
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault account to initialize
/// 2. `[signer]` manager: [AccountInfo] The vault manager account
/// 3. `[writable, signer]` share_mint: [Mint] SPL mint for vault shares
/// 4. `[writable, signer]` vault_usdc_ata: [AccountInfo] Vault's USDC token account
/// 5. `[]` usdc_mint: [Mint] USDC mint account
/// 6. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
/// 7. `[writable]` mint: [Mint] 
/// 8. `[writable, signer]` funding: [AccountInfo] Funding account (must be a system account)
/// 9. `[writable]` assoc_token_account: [AccountInfo] Associated token account address to be created
/// 10. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 11. `[]` token_program: [AccountInfo] SPL Token program
/// 12. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
/// 13. `[]` associated_token_program: [AccountInfo] Auto-generated, AssociatedTokenProgram
///
/// Data:
/// - fee_collector: [Pubkey] Account to receive fees
/// - name: [String] Unique name for the vault
/// - management_fee_bps: [u16] Annual management fee in basis points
/// - profit_share_bps: [u16] Profit share fee in basis points
/// - hurdle_rate_bps: [u16] Hurdle rate in basis points
/// - redeem_period: [u64] Withdrawal timelock period in seconds
/// - min_deposit_amount: [u64] Minimum deposit amount
pub fn handler(
	ctx: Context<InitializeVault>,
	fee_collector: Pubkey,
	name: String,
	management_fee_bps: u16,
	profit_share_bps: u16,
	hurdle_rate_bps: u16,
	redeem_period: u64,
	min_deposit_amount: u64,
) -> Result<()> {
    // Implement your business logic here...
	
	// Cpi calls wrappers
	ctx.accounts.cpi_token_initialize_mint2(
		Default::default(),
	Pubkey::default(),
	None,
	)?;

	Ok(())
}
