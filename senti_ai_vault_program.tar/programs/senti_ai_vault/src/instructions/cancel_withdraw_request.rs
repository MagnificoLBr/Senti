use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
)]
pub struct CancelWithdrawRequest<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	#[account(
		mut,
		close=fee_payer,
		seeds = [
			b"withdraw_request",
			vault.key().as_ref(),
			user.key().as_ref(),
		],
		bump,
	)]
	pub withdraw_request: Account<'info, WithdrawRequest>,

	pub user: Signer<'info>,
}

/// Cancel a pending withdrawal request
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[]` vault: [Vault] The vault the request belongs to
/// 2. `[writable]` withdraw_request: [WithdrawRequest] Withdrawal request to cancel
/// 3. `[signer]` user: [AccountInfo] The user canceling the request
///
/// Data:
/// - name: [String] Vault name for PDA derivation
pub fn handler(
	ctx: Context<CancelWithdrawRequest>,
	name: String,
) -> Result<()> {
    // Implement your business logic here...
	
	Ok(())
}
