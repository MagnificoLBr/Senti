use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
	shares: u64,
)]
pub struct RequestWithdraw<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	#[account(
		seeds = [
			b"vault_depositor",
			vault.key().as_ref(),
			user.key().as_ref(),
		],
		bump,
	)]
	pub vault_depositor: Account<'info, VaultDepositor>,

	#[account(
		init,
		space=97,
		payer=fee_payer,
		seeds = [
			b"withdraw_request",
			vault.key().as_ref(),
			user.key().as_ref(),
		],
		bump,
	)]
	pub withdraw_request: Account<'info, WithdrawRequest>,

	pub user: Signer<'info>,

	pub system_program: Program<'info, System>,
}

/// Request withdrawal with timelock period
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[]` vault: [Vault] The vault to withdraw from
/// 2. `[]` vault_depositor: [VaultDepositor] User's depositor account
/// 3. `[writable]` withdraw_request: [WithdrawRequest] Withdrawal request account
/// 4. `[signer]` user: [AccountInfo] The user requesting withdrawal
/// 5. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - shares: [u64] Number of shares to withdraw
pub fn handler(
	ctx: Context<RequestWithdraw>,
	name: String,
	shares: u64,
) -> Result<()> {
    // Implement your business logic here...
	
	Ok(())
}
