use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
)]
pub struct Withdraw<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		mut,
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	#[account(
		mut,
		seeds = [
			b"vault_depositor",
			vault.key().as_ref(),
			user.key().as_ref(),
		],
		bump,
	)]
	pub vault_depositor: Account<'info, VaultDepositor>,

	#[account(
		mut,
		close=fee_payer,
		seeds = [
			b"withdraw_request",
			vault.key().as_ref(),
			user.key().as_ref(),
		],
		bump,
	)]
	pub withdraw_request: Account<'info, WithdrawRequest>,

	pub user: Signer<'info>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub user_usdc_ata: UncheckedAccount<'info>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub vault_usdc_ata: UncheckedAccount<'info>,

	#[account(mut)]
	pub share_mint: Account<'info, Mint>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub user_share_ata: UncheckedAccount<'info>,

	#[account(mut)]
	pub account: Account<'info, TokenAccount>,

	#[account(mut)]
	pub mint: Account<'info, Mint>,

	pub owner: Signer<'info>,

	/// CHECK: implement manual checks if needed
	pub wallet: UncheckedAccount<'info>,

	pub token_program: Program<'info, Token>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub source: UncheckedAccount<'info>,

	#[account(
		mut,
	)]
	/// CHECK: implement manual checks if needed
	pub destination: UncheckedAccount<'info>,

	pub authority: Signer<'info>,

	pub token_program: Program<'info, Token>,
}

impl<'info> Withdraw<'info> {
	pub fn cpi_token_burn(&self, amount: u64) -> Result<()> {
		anchor_spl::token::burn(
			CpiContext::new(self.token_program.to_account_info(), 
				anchor_spl::token::Burn {
					from: self.account.to_account_info(),
					mint: self.mint.to_account_info(),
					authority: self.owner.to_account_info()
				}
			),
			amount, 
		)
	}
	pub fn cpi_token_transfer_checked(&self, amount: u64, decimals: u8) -> Result<()> {
		anchor_spl::token::transfer_checked(
			CpiContext::new(self.token_program.to_account_info(), 
				anchor_spl::token::TransferChecked {
					from: self.source.to_account_info(),
					mint: self.mint.to_account_info(),
					to: self.destination.to_account_info(),
					authority: self.authority.to_account_info()
				}
			),
			amount, 
			decimals, 
		)
	}
}


/// Execute queued withdrawal after timelock period
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to withdraw from
/// 2. `[writable]` vault_depositor: [VaultDepositor] User's depositor account
/// 3. `[writable]` withdraw_request: [WithdrawRequest] Withdrawal request to execute
/// 4. `[signer]` user: [AccountInfo] The user executing withdrawal
/// 5. `[writable]` user_usdc_ata: [AccountInfo] User's USDC token account
/// 6. `[writable]` vault_usdc_ata: [AccountInfo] Vault's USDC token account
/// 7. `[writable]` share_mint: [Mint] Vault share mint
/// 8. `[writable]` user_share_ata: [AccountInfo] User's share token account
/// 9. `[writable]` account: [Account] The account to burn from.
/// 10. `[writable]` mint: [Mint] The token mint.
/// 11. `[signer]` owner: [AccountInfo] The account's owner/delegate.
/// 12. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 13. `[]` token_program: [AccountInfo] SPL Token program
/// 14. `[writable]` source: [AccountInfo] The source account.
/// 15. `[writable]` destination: [AccountInfo] The destination account.
/// 16. `[signer]` authority: [AccountInfo] The source account's owner/delegate.
/// 17. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
///
/// Data:
/// - name: [String] Vault name for PDA derivation
pub fn handler(
	ctx: Context<Withdraw>,
	name: String,
) -> Result<()> {
    // Implement your business logic here...
	
	// Cpi calls wrappers
	ctx.accounts.cpi_token_burn(
		Default::default(),
	)?;

	ctx.accounts.cpi_token_transfer_checked(
		Default::default(),
		Default::default(),
	)?;

	Ok(())
}
