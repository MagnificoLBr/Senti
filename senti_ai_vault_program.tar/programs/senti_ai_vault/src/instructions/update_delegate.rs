use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
	new_delegate: Option<Pubkey>,
)]
pub struct UpdateDelegate<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		mut,
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	pub manager: Signer<'info>,
}

/// Set or change the Drift trading delegate
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to update
/// 2. `[signer]` manager: [AccountInfo] Vault manager account
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - new_delegate: [Option<Pubkey>] New delegate pubkey (None to remove)
pub fn handler(
	ctx: Context<UpdateDelegate>,
	name: String,
	new_delegate: Option<Pubkey>,
) -> Result<()> {
    // Implement your business logic here...
	
	Ok(())
}
