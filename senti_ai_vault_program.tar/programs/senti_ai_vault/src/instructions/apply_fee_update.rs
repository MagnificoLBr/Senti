use crate::*;
use anchor_lang::prelude::*;
use std::str::FromStr;

use anchor_spl::{
    associated_token::AssociatedToken,
    token::{Mint, Token, TokenAccount},
};

#[derive(Accounts)]
#[instruction(
	name: String,
)]
pub struct ApplyFeeUpdate<'info> {
	#[account(
		mut,
	)]
	pub fee_payer: Signer<'info>,

	#[account(
		mut,
		seeds = [
			b"vault",
			name.as_bytes().as_ref(),
		],
		bump,
	)]
	pub vault: Account<'info, Vault>,

	#[account(
		mut,
		close=fee_payer,
		seeds = [
			b"fee_update",
			vault.key().as_ref(),
		],
		bump,
	)]
	pub fee_update: Account<'info, FeeUpdate>,

	pub manager: Signer<'info>,
}

/// Apply staged fee update after timelock period
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to update
/// 2. `[writable]` fee_update: [FeeUpdate] Fee update to apply
/// 3. `[signer]` manager: [AccountInfo] Vault manager account
///
/// Data:
/// - name: [String] Vault name for PDA derivation
pub fn handler(
	ctx: Context<ApplyFeeUpdate>,
	name: String,
) -> Result<()> {
    // Implement your business logic here...
	
	Ok(())
}
