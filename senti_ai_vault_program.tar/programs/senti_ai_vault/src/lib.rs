
pub mod constants;
pub mod error;
pub mod instructions;
pub mod state;

use anchor_lang::prelude::*;
use std::str::FromStr;

pub use constants::*;
pub use instructions::*;
pub use state::*;
pub use error::*;

declare_id!("HmGWQfMg26aoeCbyh4bifVZwpGU9dB94RxnGAk7LnMhD");

#[program]
pub mod senti_ai_vault {
    use super::*;

/// Creates a new vault with share mint and USDC ATA
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault account to initialize
/// 2. `[signer]` manager: [AccountInfo] The vault manager account
/// 3. `[writable, signer]` share_mint: [Mint] SPL mint for vault shares
/// 4. `[writable, signer]` vault_usdc_ata: [AccountInfo] Vault's USDC token account
/// 5. `[]` usdc_mint: [Mint] USDC mint account
/// 6. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
/// 7. `[writable]` mint: [Mint] 
/// 8. `[writable, signer]` funding: [AccountInfo] Funding account (must be a system account)
/// 9. `[writable]` assoc_token_account: [AccountInfo] Associated token account address to be created
/// 10. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 11. `[]` token_program: [AccountInfo] SPL Token program
/// 12. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
/// 13. `[]` associated_token_program: [AccountInfo] Auto-generated, AssociatedTokenProgram
///
/// Data:
/// - fee_collector: [Pubkey] Account to receive fees
/// - name: [String] Unique name for the vault
/// - management_fee_bps: [u16] Annual management fee in basis points
/// - profit_share_bps: [u16] Profit share fee in basis points
/// - hurdle_rate_bps: [u16] Hurdle rate in basis points
/// - redeem_period: [u64] Withdrawal timelock period in seconds
/// - min_deposit_amount: [u64] Minimum deposit amount
	pub fn initialize_vault(ctx: Context<InitializeVault>, fee_collector: Pubkey, name: String, management_fee_bps: u16, profit_share_bps: u16, hurdle_rate_bps: u16, redeem_period: u64, min_deposit_amount: u64) -> Result<()> {
		initialize_vault::handler(ctx, fee_collector, name, management_fee_bps, profit_share_bps, hurdle_rate_bps, redeem_period, min_deposit_amount)
	}

/// User deposits USDC and receives vault shares pro-rata
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to deposit into
/// 2. `[writable]` vault_depositor: [VaultDepositor] User's depositor account
/// 3. `[signer]` user: [AccountInfo] The user making the deposit
/// 4. `[writable]` user_usdc_ata: [AccountInfo] User's USDC token account
/// 5. `[writable]` vault_usdc_ata: [AccountInfo] Vault's USDC token account
/// 6. `[writable]` share_mint: [Mint] Vault share mint
/// 7. `[writable, signer]` user_share_ata: [AccountInfo] User's share token account
/// 8. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
/// 9. `[writable]` source: [AccountInfo] The source account.
/// 10. `[writable]` mint: [Mint] The token mint.
/// 11. `[writable]` destination: [AccountInfo] The destination account.
/// 12. `[signer]` authority: [AccountInfo] The source account's owner/delegate.
/// 13. `[writable]` assoc_token_account: [Account] The account to mint tokens to.
/// 14. `[signer]` owner: [AccountInfo] The mint's minting authority.
/// 15. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 16. `[]` token_program: [AccountInfo] SPL Token program
/// 17. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - amount: [u64] Amount of USDC to deposit
	pub fn deposit(ctx: Context<Deposit>, name: String, amount: u64) -> Result<()> {
		deposit::handler(ctx, name, amount)
	}

/// Request withdrawal with timelock period
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[]` vault: [Vault] The vault to withdraw from
/// 2. `[]` vault_depositor: [VaultDepositor] User's depositor account
/// 3. `[writable]` withdraw_request: [WithdrawRequest] Withdrawal request account
/// 4. `[signer]` user: [AccountInfo] The user requesting withdrawal
/// 5. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - shares: [u64] Number of shares to withdraw
	pub fn request_withdraw(ctx: Context<RequestWithdraw>, name: String, shares: u64) -> Result<()> {
		request_withdraw::handler(ctx, name, shares)
	}

/// Cancel a pending withdrawal request
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[]` vault: [Vault] The vault the request belongs to
/// 2. `[writable]` withdraw_request: [WithdrawRequest] Withdrawal request to cancel
/// 3. `[signer]` user: [AccountInfo] The user canceling the request
///
/// Data:
/// - name: [String] Vault name for PDA derivation
	pub fn cancel_withdraw_request(ctx: Context<CancelWithdrawRequest>, name: String) -> Result<()> {
		cancel_withdraw_request::handler(ctx, name)
	}

/// Execute queued withdrawal after timelock period
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to withdraw from
/// 2. `[writable]` vault_depositor: [VaultDepositor] User's depositor account
/// 3. `[writable]` withdraw_request: [WithdrawRequest] Withdrawal request to execute
/// 4. `[signer]` user: [AccountInfo] The user executing withdrawal
/// 5. `[writable]` user_usdc_ata: [AccountInfo] User's USDC token account
/// 6. `[writable]` vault_usdc_ata: [AccountInfo] Vault's USDC token account
/// 7. `[writable]` share_mint: [Mint] Vault share mint
/// 8. `[writable]` user_share_ata: [AccountInfo] User's share token account
/// 9. `[writable]` account: [Account] The account to burn from.
/// 10. `[writable]` mint: [Mint] The token mint.
/// 11. `[signer]` owner: [AccountInfo] The account's owner/delegate.
/// 12. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 13. `[]` token_program: [AccountInfo] SPL Token program
/// 14. `[writable]` source: [AccountInfo] The source account.
/// 15. `[writable]` destination: [AccountInfo] The destination account.
/// 16. `[signer]` authority: [AccountInfo] The source account's owner/delegate.
/// 17. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
///
/// Data:
/// - name: [String] Vault name for PDA derivation
	pub fn withdraw(ctx: Context<Withdraw>, name: String) -> Result<()> {
		withdraw::handler(ctx, name)
	}

/// Stage new fee parameters with timelock
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[]` vault: [Vault] The vault to update fees for
/// 2. `[writable]` fee_update: [FeeUpdate] Fee update staging account
/// 3. `[signer]` manager: [AccountInfo] Vault manager account
/// 4. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - new_management_fee_bps: [u16] New management fee in basis points
/// - new_profit_share_bps: [u16] New profit share fee in basis points
/// - new_hurdle_rate_bps: [u16] New hurdle rate in basis points
/// - timelock_period: [u64] Timelock period in seconds
	pub fn start_fee_update(ctx: Context<StartFeeUpdate>, name: String, new_management_fee_bps: u16, new_profit_share_bps: u16, new_hurdle_rate_bps: u16, timelock_period: u64) -> Result<()> {
		start_fee_update::handler(ctx, name, new_management_fee_bps, new_profit_share_bps, new_hurdle_rate_bps, timelock_period)
	}

/// Apply staged fee update after timelock period
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to update
/// 2. `[writable]` fee_update: [FeeUpdate] Fee update to apply
/// 3. `[signer]` manager: [AccountInfo] Vault manager account
///
/// Data:
/// - name: [String] Vault name for PDA derivation
	pub fn apply_fee_update(ctx: Context<ApplyFeeUpdate>, name: String) -> Result<()> {
		apply_fee_update::handler(ctx, name)
	}

/// Set or change the Drift trading delegate
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to update
/// 2. `[signer]` manager: [AccountInfo] Vault manager account
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - new_delegate: [Option<Pubkey>] New delegate pubkey (None to remove)
	pub fn update_delegate(ctx: Context<UpdateDelegate>, name: String, new_delegate: Option<Pubkey>) -> Result<()> {
		update_delegate::handler(ctx, name, new_delegate)
	}

/// Update vault parameters (manager only)
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to update
/// 2. `[signer]` manager: [AccountInfo] Vault manager account
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - new_min_deposit_amount: [Option<u64>] New minimum deposit amount
/// - new_redeem_period: [Option<u64>] New withdrawal timelock period
/// - new_paused: [Option<bool>] New paused status
	pub fn update_vault(ctx: Context<UpdateVault>, name: String, new_min_deposit_amount: Option<u64>, new_redeem_period: Option<u64>, new_paused: Option<bool>) -> Result<()> {
		update_vault::handler(ctx, name, new_min_deposit_amount, new_redeem_period, new_paused)
	}

/// Crystallize profit share vs high watermark and mint manager shares
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to apply profit share for
/// 2. `[signer]` manager: [AccountInfo] Vault manager account
/// 3. `[writable]` share_mint: [Mint] Vault share mint
/// 4. `[writable, signer]` fee_collector_share_ata: [AccountInfo] Fee collector's share token account
/// 5. `[]` system_program: [AccountInfo] Auto-generated, for account initialization
/// 6. `[writable]` mint: [Mint] The mint.
/// 7. `[writable]` assoc_token_account: [Account] The account to mint tokens to.
/// 8. `[signer]` owner: [AccountInfo] The mint's minting authority.
/// 9. `[]` wallet: [AccountInfo] Wallet address for the new associated token account
/// 10. `[]` token_program: [AccountInfo] SPL Token program
/// 11. `[]` token_program: [AccountInfo] Auto-generated, TokenProgram
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - current_equity: [u64] Current vault equity value
	pub fn apply_profit_share(ctx: Context<ApplyProfitShare>, name: String, current_equity: u64) -> Result<()> {
		apply_profit_share::handler(ctx, name, current_equity)
	}

/// Adjust total shares when equity is much smaller than shares
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to rebase
/// 2. `[signer]` manager: [AccountInfo] Vault manager account
///
/// Data:
/// - name: [String] Vault name for PDA derivation
/// - new_total_shares: [u64] New total shares amount
	pub fn apply_rebase(ctx: Context<ApplyRebase>, name: String, new_total_shares: u64) -> Result<()> {
		apply_rebase::handler(ctx, name, new_total_shares)
	}

/// Mark vault as in liquidation mode
///
/// Accounts:
/// 0. `[writable, signer]` fee_payer: [AccountInfo] 
/// 1. `[writable]` vault: [Vault] The vault to liquidate
/// 2. `[signer]` manager: [AccountInfo] Vault manager account
///
/// Data:
/// - name: [String] Vault name for PDA derivation
	pub fn liquidate(ctx: Context<Liquidate>, name: String) -> Result<()> {
		liquidate::handler(ctx, name)
	}



}
