import { AnchorProvider } from "@coral-xyz/anchor";
import {
  Keypair,
  PublicKey,
  type AccountMeta,
  type TransactionInstruction,
  type TransactionSignature,
} from "@solana/web3.js";
import { useCallback, useState, useEffect } from "react";
import { useConnection } from "@solana/wallet-adapter-react";
import * as programClient from "~/solana/client";

// Props interface for the useProgram hook
export interface UseProgramProps {
  // Optional override for the VITE_SOLANA_PROGRAM_ID env var
  programId?: string;
}

// Error structure returned from sendAndConfirmTx if transaction fails
type SendAndConfirmTxError = {
  message: string;
  logs: string[];
  stack: string | undefined;
};

// Result structure returned from sendAndConfirmTx
type SendAndConfirmTxResult = {
  // Signature of successful transaction
  signature?: string;

  // Error details if transaction fails
  error?: SendAndConfirmTxError;
};

// Helper function to send and confirm a transaction, with error handling
const sendAndConfirmTx = async (
  fn: () => Promise<TransactionSignature>,
): Promise<SendAndConfirmTxResult> => {
  try {
    const signature = await fn();
    return {
      signature,
    };
  } catch (e: any) {
    let message = `An unknown error occurred: ${e}`;
    let logs = [];
    let stack = "";

    if ("logs" in e && e.logs instanceof Array) {
      logs = e.logs;
    }

    if ("stack" in e) {
      stack = e.stack;
    }

    if ("message" in e) {
      message = e.message;
    }

    return {
      error: {
        logs,
        stack,
        message,
      },
    };
  }
};

const useProgram = (props?: UseProgramProps | undefined) => {
  const [programId, setProgramId] = useState<PublicKey|undefined>(undefined)
  const { connection } = useConnection();

  useEffect(() => {
    let prgId = import.meta.env.VITE_SOLANA_PROGRAM_ID as string | undefined;

    if (props?.programId) {
      prgId = props.programId;
    }

    if (!prgId) {
      throw new Error(
        "the program id must be provided either by the useProgram props or the env var VITE_SOLANA_PROGRAM_ID",
      );
    }

    const pid = new PublicKey(prgId)
    setProgramId(pid)
    programClient.initializeClient(pid, new AnchorProvider(connection));
  }, [props?.programId, connection.rpcEndpoint]);

  /**
   * Creates a new vault with share mint and USDC ATA
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault account to initialize
   * 2. `[signer]` manager: {@link PublicKey} The vault manager account
   * 3. `[writable, signer]` share_mint: {@link Mint} SPL mint for vault shares
   * 4. `[writable, signer]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
   * 5. `[]` usdc_mint: {@link Mint} USDC mint account
   * 6. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   * 7. `[writable]` mint: {@link Mint} 
   * 8. `[writable, signer]` funding: {@link PublicKey} Funding account (must be a system account)
   * 9. `[writable]` assoc_token_account: {@link PublicKey} Associated token account address to be created
   * 10. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 11. `[]` token_program: {@link PublicKey} SPL Token program
   * 12. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   * 13. `[]` associated_token_program: {@link PublicKey} Auto-generated, AssociatedTokenProgram
   *
   * Data:
   * - fee_collector: {@link PublicKey} Account to receive fees
   * - name: {@link string} Unique name for the vault
   * - management_fee_bps: {@link number} Annual management fee in basis points
   * - profit_share_bps: {@link number} Profit share fee in basis points
   * - hurdle_rate_bps: {@link number} Hurdle rate in basis points
   * - redeem_period: {@link BigInt} Withdrawal timelock period in seconds
   * - min_deposit_amount: {@link BigInt} Minimum deposit amount
   *
   * @returns {@link TransactionInstruction}
   */
  const initializeVault = useCallback(programClient.initializeVault, [])

  /**
   * Creates a new vault with share mint and USDC ATA
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault account to initialize
   * 2. `[signer]` manager: {@link PublicKey} The vault manager account
   * 3. `[writable, signer]` share_mint: {@link Mint} SPL mint for vault shares
   * 4. `[writable, signer]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
   * 5. `[]` usdc_mint: {@link Mint} USDC mint account
   * 6. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   * 7. `[writable]` mint: {@link Mint} 
   * 8. `[writable, signer]` funding: {@link PublicKey} Funding account (must be a system account)
   * 9. `[writable]` assoc_token_account: {@link PublicKey} Associated token account address to be created
   * 10. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 11. `[]` token_program: {@link PublicKey} SPL Token program
   * 12. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   * 13. `[]` associated_token_program: {@link PublicKey} Auto-generated, AssociatedTokenProgram
   *
   * Data:
   * - fee_collector: {@link PublicKey} Account to receive fees
   * - name: {@link string} Unique name for the vault
   * - management_fee_bps: {@link number} Annual management fee in basis points
   * - profit_share_bps: {@link number} Profit share fee in basis points
   * - hurdle_rate_bps: {@link number} Hurdle rate in basis points
   * - redeem_period: {@link BigInt} Withdrawal timelock period in seconds
   * - min_deposit_amount: {@link BigInt} Minimum deposit amount
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const initializeVaultSendAndConfirm = useCallback(async (
    args: Omit<programClient.InitializeVaultArgs, "feePayer" | "manager" | "shareMint" | "vaultUsdcAta" | "funding"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
        shareMint: Keypair,
        vaultUsdcAta: Keypair,
        funding: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.initializeVaultSendAndConfirm(args, remainingAccounts)), [])

  /**
   * User deposits USDC and receives vault shares pro-rata
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to deposit into
   * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
   * 3. `[signer]` user: {@link PublicKey} The user making the deposit
   * 4. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
   * 5. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
   * 6. `[writable]` share_mint: {@link Mint} Vault share mint
   * 7. `[writable, signer]` user_share_ata: {@link PublicKey} User's share token account
   * 8. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   * 9. `[writable]` source: {@link PublicKey} The source account.
   * 10. `[writable]` mint: {@link Mint} The token mint.
   * 11. `[writable]` destination: {@link PublicKey} The destination account.
   * 12. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
   * 13. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
   * 14. `[signer]` owner: {@link PublicKey} The mint's minting authority.
   * 15. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 16. `[]` token_program: {@link PublicKey} SPL Token program
   * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - amount: {@link BigInt} Amount of USDC to deposit
   *
   * @returns {@link TransactionInstruction}
   */
  const deposit = useCallback(programClient.deposit, [])

  /**
   * User deposits USDC and receives vault shares pro-rata
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to deposit into
   * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
   * 3. `[signer]` user: {@link PublicKey} The user making the deposit
   * 4. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
   * 5. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
   * 6. `[writable]` share_mint: {@link Mint} Vault share mint
   * 7. `[writable, signer]` user_share_ata: {@link PublicKey} User's share token account
   * 8. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   * 9. `[writable]` source: {@link PublicKey} The source account.
   * 10. `[writable]` mint: {@link Mint} The token mint.
   * 11. `[writable]` destination: {@link PublicKey} The destination account.
   * 12. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
   * 13. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
   * 14. `[signer]` owner: {@link PublicKey} The mint's minting authority.
   * 15. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 16. `[]` token_program: {@link PublicKey} SPL Token program
   * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - amount: {@link BigInt} Amount of USDC to deposit
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const depositSendAndConfirm = useCallback(async (
    args: Omit<programClient.DepositArgs, "feePayer" | "user" | "userShareAta" | "authority" | "owner"> & {
    signers: {
        feePayer: Keypair,
        user: Keypair,
        userShareAta: Keypair,
        authority: Keypair,
        owner: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.depositSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Request withdrawal with timelock period
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[]` vault: {@link Vault} The vault to withdraw from
   * 2. `[]` vault_depositor: {@link VaultDepositor} User's depositor account
   * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request account
   * 4. `[signer]` user: {@link PublicKey} The user requesting withdrawal
   * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - shares: {@link BigInt} Number of shares to withdraw
   *
   * @returns {@link TransactionInstruction}
   */
  const requestWithdraw = useCallback(programClient.requestWithdraw, [])

  /**
   * Request withdrawal with timelock period
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[]` vault: {@link Vault} The vault to withdraw from
   * 2. `[]` vault_depositor: {@link VaultDepositor} User's depositor account
   * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request account
   * 4. `[signer]` user: {@link PublicKey} The user requesting withdrawal
   * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - shares: {@link BigInt} Number of shares to withdraw
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const requestWithdrawSendAndConfirm = useCallback(async (
    args: Omit<programClient.RequestWithdrawArgs, "feePayer" | "user"> & {
    signers: {
        feePayer: Keypair,
        user: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.requestWithdrawSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Cancel a pending withdrawal request
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[]` vault: {@link Vault} The vault the request belongs to
   * 2. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to cancel
   * 3. `[signer]` user: {@link PublicKey} The user canceling the request
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link TransactionInstruction}
   */
  const cancelWithdrawRequest = useCallback(programClient.cancelWithdrawRequest, [])

  /**
   * Cancel a pending withdrawal request
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[]` vault: {@link Vault} The vault the request belongs to
   * 2. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to cancel
   * 3. `[signer]` user: {@link PublicKey} The user canceling the request
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const cancelWithdrawRequestSendAndConfirm = useCallback(async (
    args: Omit<programClient.CancelWithdrawRequestArgs, "feePayer" | "user"> & {
    signers: {
        feePayer: Keypair,
        user: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.cancelWithdrawRequestSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Execute queued withdrawal after timelock period
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to withdraw from
   * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
   * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to execute
   * 4. `[signer]` user: {@link PublicKey} The user executing withdrawal
   * 5. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
   * 6. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
   * 7. `[writable]` share_mint: {@link Mint} Vault share mint
   * 8. `[writable]` user_share_ata: {@link PublicKey} User's share token account
   * 9. `[writable]` account: {@link Account} The account to burn from.
   * 10. `[writable]` mint: {@link Mint} The token mint.
   * 11. `[signer]` owner: {@link PublicKey} The account's owner/delegate.
   * 12. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 13. `[]` token_program: {@link PublicKey} SPL Token program
   * 14. `[writable]` source: {@link PublicKey} The source account.
   * 15. `[writable]` destination: {@link PublicKey} The destination account.
   * 16. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
   * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link TransactionInstruction}
   */
  const withdraw = useCallback(programClient.withdraw, [])

  /**
   * Execute queued withdrawal after timelock period
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to withdraw from
   * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
   * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to execute
   * 4. `[signer]` user: {@link PublicKey} The user executing withdrawal
   * 5. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
   * 6. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
   * 7. `[writable]` share_mint: {@link Mint} Vault share mint
   * 8. `[writable]` user_share_ata: {@link PublicKey} User's share token account
   * 9. `[writable]` account: {@link Account} The account to burn from.
   * 10. `[writable]` mint: {@link Mint} The token mint.
   * 11. `[signer]` owner: {@link PublicKey} The account's owner/delegate.
   * 12. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 13. `[]` token_program: {@link PublicKey} SPL Token program
   * 14. `[writable]` source: {@link PublicKey} The source account.
   * 15. `[writable]` destination: {@link PublicKey} The destination account.
   * 16. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
   * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const withdrawSendAndConfirm = useCallback(async (
    args: Omit<programClient.WithdrawArgs, "feePayer" | "user" | "owner" | "authority"> & {
    signers: {
        feePayer: Keypair,
        user: Keypair,
        owner: Keypair,
        authority: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.withdrawSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Stage new fee parameters with timelock
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[]` vault: {@link Vault} The vault to update fees for
   * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update staging account
   * 3. `[signer]` manager: {@link PublicKey} Vault manager account
   * 4. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_management_fee_bps: {@link number} New management fee in basis points
   * - new_profit_share_bps: {@link number} New profit share fee in basis points
   * - new_hurdle_rate_bps: {@link number} New hurdle rate in basis points
   * - timelock_period: {@link BigInt} Timelock period in seconds
   *
   * @returns {@link TransactionInstruction}
   */
  const startFeeUpdate = useCallback(programClient.startFeeUpdate, [])

  /**
   * Stage new fee parameters with timelock
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[]` vault: {@link Vault} The vault to update fees for
   * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update staging account
   * 3. `[signer]` manager: {@link PublicKey} Vault manager account
   * 4. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_management_fee_bps: {@link number} New management fee in basis points
   * - new_profit_share_bps: {@link number} New profit share fee in basis points
   * - new_hurdle_rate_bps: {@link number} New hurdle rate in basis points
   * - timelock_period: {@link BigInt} Timelock period in seconds
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const startFeeUpdateSendAndConfirm = useCallback(async (
    args: Omit<programClient.StartFeeUpdateArgs, "feePayer" | "manager"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.startFeeUpdateSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Apply staged fee update after timelock period
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to update
   * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update to apply
   * 3. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link TransactionInstruction}
   */
  const applyFeeUpdate = useCallback(programClient.applyFeeUpdate, [])

  /**
   * Apply staged fee update after timelock period
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to update
   * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update to apply
   * 3. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const applyFeeUpdateSendAndConfirm = useCallback(async (
    args: Omit<programClient.ApplyFeeUpdateArgs, "feePayer" | "manager"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.applyFeeUpdateSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Set or change the Drift trading delegate
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to update
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_delegate: {@link PublicKey | undefined} New delegate pubkey (None to remove)
   *
   * @returns {@link TransactionInstruction}
   */
  const updateDelegate = useCallback(programClient.updateDelegate, [])

  /**
   * Set or change the Drift trading delegate
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to update
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_delegate: {@link PublicKey | undefined} New delegate pubkey (None to remove)
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const updateDelegateSendAndConfirm = useCallback(async (
    args: Omit<programClient.UpdateDelegateArgs, "feePayer" | "manager"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.updateDelegateSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Update vault parameters (manager only)
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to update
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_min_deposit_amount: {@link BigInt | undefined} New minimum deposit amount
   * - new_redeem_period: {@link BigInt | undefined} New withdrawal timelock period
   * - new_paused: {@link boolean | undefined} New paused status
   *
   * @returns {@link TransactionInstruction}
   */
  const updateVault = useCallback(programClient.updateVault, [])

  /**
   * Update vault parameters (manager only)
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to update
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_min_deposit_amount: {@link BigInt | undefined} New minimum deposit amount
   * - new_redeem_period: {@link BigInt | undefined} New withdrawal timelock period
   * - new_paused: {@link boolean | undefined} New paused status
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const updateVaultSendAndConfirm = useCallback(async (
    args: Omit<programClient.UpdateVaultArgs, "feePayer" | "manager"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.updateVaultSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Crystallize profit share vs high watermark and mint manager shares
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to apply profit share for
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   * 3. `[writable]` share_mint: {@link Mint} Vault share mint
   * 4. `[writable, signer]` fee_collector_share_ata: {@link PublicKey} Fee collector's share token account
   * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   * 6. `[writable]` mint: {@link Mint} The mint.
   * 7. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
   * 8. `[signer]` owner: {@link PublicKey} The mint's minting authority.
   * 9. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 10. `[]` token_program: {@link PublicKey} SPL Token program
   * 11. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - current_equity: {@link BigInt} Current vault equity value
   *
   * @returns {@link TransactionInstruction}
   */
  const applyProfitShare = useCallback(programClient.applyProfitShare, [])

  /**
   * Crystallize profit share vs high watermark and mint manager shares
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to apply profit share for
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   * 3. `[writable]` share_mint: {@link Mint} Vault share mint
   * 4. `[writable, signer]` fee_collector_share_ata: {@link PublicKey} Fee collector's share token account
   * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
   * 6. `[writable]` mint: {@link Mint} The mint.
   * 7. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
   * 8. `[signer]` owner: {@link PublicKey} The mint's minting authority.
   * 9. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
   * 10. `[]` token_program: {@link PublicKey} SPL Token program
   * 11. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - current_equity: {@link BigInt} Current vault equity value
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const applyProfitShareSendAndConfirm = useCallback(async (
    args: Omit<programClient.ApplyProfitShareArgs, "feePayer" | "manager" | "feeCollectorShareAta" | "owner"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
        feeCollectorShareAta: Keypair,
        owner: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.applyProfitShareSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Adjust total shares when equity is much smaller than shares
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to rebase
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_total_shares: {@link BigInt} New total shares amount
   *
   * @returns {@link TransactionInstruction}
   */
  const applyRebase = useCallback(programClient.applyRebase, [])

  /**
   * Adjust total shares when equity is much smaller than shares
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to rebase
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   * - new_total_shares: {@link BigInt} New total shares amount
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const applyRebaseSendAndConfirm = useCallback(async (
    args: Omit<programClient.ApplyRebaseArgs, "feePayer" | "manager"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.applyRebaseSendAndConfirm(args, remainingAccounts)), [])

  /**
   * Mark vault as in liquidation mode
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to liquidate
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link TransactionInstruction}
   */
  const liquidate = useCallback(programClient.liquidate, [])

  /**
   * Mark vault as in liquidation mode
   *
   * Accounts:
   * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
   * 1. `[writable]` vault: {@link Vault} The vault to liquidate
   * 2. `[signer]` manager: {@link PublicKey} Vault manager account
   *
   * Data:
   * - name: {@link string} Vault name for PDA derivation
   *
   * @returns {@link SendAndConfirmTxResult}
   */
  const liquidateSendAndConfirm = useCallback(async (
    args: Omit<programClient.LiquidateArgs, "feePayer" | "manager"> & {
    signers: {
        feePayer: Keypair,
        manager: Keypair,
    }}, 
    remainingAccounts: Array<AccountMeta> = []
  ): Promise<SendAndConfirmTxResult> => sendAndConfirmTx(() => programClient.liquidateSendAndConfirm(args, remainingAccounts)), [])


  const getVault = useCallback(programClient.getVault, [])
  const getVaultDepositor = useCallback(programClient.getVaultDepositor, [])
  const getWithdrawRequest = useCallback(programClient.getWithdrawRequest, [])
  const getFeeUpdate = useCallback(programClient.getFeeUpdate, [])

  const deriveVault = useCallback(programClient.deriveVaultPDA,[])
  const deriveVaultDepositor = useCallback(programClient.deriveVaultDepositorPDA,[])
  const deriveWithdrawRequest = useCallback(programClient.deriveWithdrawRequestPDA,[])
  const deriveFeeUpdate = useCallback(programClient.deriveFeeUpdatePDA,[])
  const deriveAccountFromTokenProgram = useCallback(programClient.TokenProgramPDAs.deriveAccountPDA, [])

  return {
	programId,
    initializeVault,
    initializeVaultSendAndConfirm,
    deposit,
    depositSendAndConfirm,
    requestWithdraw,
    requestWithdrawSendAndConfirm,
    cancelWithdrawRequest,
    cancelWithdrawRequestSendAndConfirm,
    withdraw,
    withdrawSendAndConfirm,
    startFeeUpdate,
    startFeeUpdateSendAndConfirm,
    applyFeeUpdate,
    applyFeeUpdateSendAndConfirm,
    updateDelegate,
    updateDelegateSendAndConfirm,
    updateVault,
    updateVaultSendAndConfirm,
    applyProfitShare,
    applyProfitShareSendAndConfirm,
    applyRebase,
    applyRebaseSendAndConfirm,
    liquidate,
    liquidateSendAndConfirm,
    getVault,
    getVaultDepositor,
    getWithdrawRequest,
    getFeeUpdate,
    deriveVault,
    deriveVaultDepositor,
    deriveWithdrawRequest,
    deriveFeeUpdate,
    deriveAccountFromTokenProgram,
  };
};

export { useProgram };