import {PublicKey} from "@solana/web3.js";
import BN from "bn.js";

export type VaultSeeds = {
    name: string, 
};

export const deriveVaultPDA = (
    seeds: VaultSeeds,
    programId: PublicKey
): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [
            Buffer.from("vault"),
            Buffer.from(seeds.name, "utf8"),
        ],
        programId,
    )
};

export type VaultDepositorSeeds = {
    vault: PublicKey, 
    user: PublicKey, 
};

export const deriveVaultDepositorPDA = (
    seeds: VaultDepositorSeeds,
    programId: PublicKey
): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [
            Buffer.from("vault_depositor"),
            seeds.vault.toBuffer(),
            seeds.user.toBuffer(),
        ],
        programId,
    )
};

export type WithdrawRequestSeeds = {
    vault: PublicKey, 
    user: PublicKey, 
};

export const deriveWithdrawRequestPDA = (
    seeds: WithdrawRequestSeeds,
    programId: PublicKey
): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [
            Buffer.from("withdraw_request"),
            seeds.vault.toBuffer(),
            seeds.user.toBuffer(),
        ],
        programId,
    )
};

export type FeeUpdateSeeds = {
    vault: PublicKey, 
};

export const deriveFeeUpdatePDA = (
    seeds: FeeUpdateSeeds,
    programId: PublicKey
): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [
            Buffer.from("fee_update"),
            seeds.vault.toBuffer(),
        ],
        programId,
    )
};

export module TokenProgramPDAs {
    export type AccountSeeds = {
        wallet: PublicKey, 
        tokenProgram: PublicKey, 
        mint: PublicKey, 
    };
    
    export const deriveAccountPDA = (
        seeds: AccountSeeds,
        programId: PublicKey
    ): [PublicKey, number] => {
        return PublicKey.findProgramAddressSync(
            [
                seeds.wallet.toBuffer(),
                seeds.tokenProgram.toBuffer(),
                seeds.mint.toBuffer(),
            ],
            programId,
        )
    };
    
}

export module AssociatedTokenProgramPDAs {
    export module TokenProgramPDAs {
        export type AccountSeeds = {
            wallet: PublicKey, 
            tokenProgram: PublicKey, 
            mint: PublicKey, 
        };
        
        export const deriveAccountPDA = (
            seeds: AccountSeeds,
            programId: PublicKey
        ): [PublicKey, number] => {
            return PublicKey.findProgramAddressSync(
                [
                    seeds.wallet.toBuffer(),
                    seeds.tokenProgram.toBuffer(),
                    seeds.mint.toBuffer(),
                ],
                programId,
            )
        };
        
    }
    
}

