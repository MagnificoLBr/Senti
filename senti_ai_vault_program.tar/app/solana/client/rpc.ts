import BN from "bn.js";
import {
  AnchorProvider,
  type IdlAccounts,
  Program,
  web3,
} from "@coral-xyz/anchor";
import { MethodsBuilder } from "@coral-xyz/anchor/dist/cjs/program/namespace/methods";
import type { SentiAiVault } from "../../../target/types/senti_ai_vault";
import idl from "../../../target/idl/senti_ai_vault.json";
import * as pda from "./pda";



let _program: Program<SentiAiVault>;


export const initializeClient = (
    programId: web3.PublicKey,
    anchorProvider = AnchorProvider.env(),
) => {
    _program = new Program<SentiAiVault>(
        idl as SentiAiVault,
        anchorProvider,
    );


};

export type InitializeVaultArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  shareMint: web3.PublicKey;
  vaultUsdcAta: web3.PublicKey;
  usdcMint: web3.PublicKey;
  mint: web3.PublicKey;
  funding: web3.PublicKey;
  wallet: web3.PublicKey;
  feeCollector: web3.PublicKey;
  name: string;
  managementFeeBps: number;
  profitShareBps: number;
  hurdleRateBps: number;
  redeemPeriod: bigint;
  minDepositAmount: bigint;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Creates a new vault with share mint and USDC ATA
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault account to initialize
 * 2. `[signer]` manager: {@link PublicKey} The vault manager account
 * 3. `[writable, signer]` share_mint: {@link Mint} SPL mint for vault shares
 * 4. `[writable, signer]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 5. `[]` usdc_mint: {@link Mint} USDC mint account
 * 6. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 7. `[writable]` mint: {@link Mint} 
 * 8. `[writable, signer]` funding: {@link PublicKey} Funding account (must be a system account)
 * 9. `[writable]` assoc_token_account: {@link PublicKey} Associated token account address to be created
 * 10. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 11. `[]` token_program: {@link PublicKey} SPL Token program
 * 12. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 * 13. `[]` associated_token_program: {@link PublicKey} Auto-generated, AssociatedTokenProgram
 *
 * Data:
 * - fee_collector: {@link PublicKey} Account to receive fees
 * - name: {@link string} Unique name for the vault
 * - management_fee_bps: {@link number} Annual management fee in basis points
 * - profit_share_bps: {@link number} Profit share fee in basis points
 * - hurdle_rate_bps: {@link number} Hurdle rate in basis points
 * - redeem_period: {@link BigInt} Withdrawal timelock period in seconds
 * - min_deposit_amount: {@link BigInt} Minimum deposit amount
 */
export const initializeVaultBuilder = (
	args: InitializeVaultArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [assocTokenAccountPubkey] = pda.CslSplTokenPDAs.deriveAccountPDA({
        wallet: args.wallet,
        tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
        mint: args.mint,
    }, new web3.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"));

  return _program
    .methods
    .initializeVault(
      args.feeCollector,
      args.name,
      args.managementFeeBps,
      args.profitShareBps,
      args.hurdleRateBps,
      new BN(args.redeemPeriod.toString()),
      new BN(args.minDepositAmount.toString()),
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      manager: args.manager,
      shareMint: args.shareMint,
      vaultUsdcAta: args.vaultUsdcAta,
      usdcMint: args.usdcMint,
      systemProgram: new web3.PublicKey("11111111111111111111111111111111"),
      mint: args.mint,
      funding: args.funding,
      assocTokenAccount: assocTokenAccountPubkey,
      wallet: args.wallet,
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
      associatedTokenProgram: new web3.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"),
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Creates a new vault with share mint and USDC ATA
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault account to initialize
 * 2. `[signer]` manager: {@link PublicKey} The vault manager account
 * 3. `[writable, signer]` share_mint: {@link Mint} SPL mint for vault shares
 * 4. `[writable, signer]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 5. `[]` usdc_mint: {@link Mint} USDC mint account
 * 6. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 7. `[writable]` mint: {@link Mint} 
 * 8. `[writable, signer]` funding: {@link PublicKey} Funding account (must be a system account)
 * 9. `[writable]` assoc_token_account: {@link PublicKey} Associated token account address to be created
 * 10. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 11. `[]` token_program: {@link PublicKey} SPL Token program
 * 12. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 * 13. `[]` associated_token_program: {@link PublicKey} Auto-generated, AssociatedTokenProgram
 *
 * Data:
 * - fee_collector: {@link PublicKey} Account to receive fees
 * - name: {@link string} Unique name for the vault
 * - management_fee_bps: {@link number} Annual management fee in basis points
 * - profit_share_bps: {@link number} Profit share fee in basis points
 * - hurdle_rate_bps: {@link number} Hurdle rate in basis points
 * - redeem_period: {@link BigInt} Withdrawal timelock period in seconds
 * - min_deposit_amount: {@link BigInt} Minimum deposit amount
 */
export const initializeVault = (
	args: InitializeVaultArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    initializeVaultBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Creates a new vault with share mint and USDC ATA
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault account to initialize
 * 2. `[signer]` manager: {@link PublicKey} The vault manager account
 * 3. `[writable, signer]` share_mint: {@link Mint} SPL mint for vault shares
 * 4. `[writable, signer]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 5. `[]` usdc_mint: {@link Mint} USDC mint account
 * 6. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 7. `[writable]` mint: {@link Mint} 
 * 8. `[writable, signer]` funding: {@link PublicKey} Funding account (must be a system account)
 * 9. `[writable]` assoc_token_account: {@link PublicKey} Associated token account address to be created
 * 10. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 11. `[]` token_program: {@link PublicKey} SPL Token program
 * 12. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 * 13. `[]` associated_token_program: {@link PublicKey} Auto-generated, AssociatedTokenProgram
 *
 * Data:
 * - fee_collector: {@link PublicKey} Account to receive fees
 * - name: {@link string} Unique name for the vault
 * - management_fee_bps: {@link number} Annual management fee in basis points
 * - profit_share_bps: {@link number} Profit share fee in basis points
 * - hurdle_rate_bps: {@link number} Hurdle rate in basis points
 * - redeem_period: {@link BigInt} Withdrawal timelock period in seconds
 * - min_deposit_amount: {@link BigInt} Minimum deposit amount
 */
export const initializeVaultSendAndConfirm = async (
  args: Omit<InitializeVaultArgs, "feePayer" | "manager" | "shareMint" | "vaultUsdcAta" | "funding"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
      shareMint: web3.Signer,
      vaultUsdcAta: web3.Signer,
      funding: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return initializeVaultBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
      shareMint: args.signers.shareMint.publicKey,
      vaultUsdcAta: args.signers.vaultUsdcAta.publicKey,
      funding: args.signers.funding.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager, args.signers.shareMint, args.signers.vaultUsdcAta, args.signers.funding])
    .rpc();
}

export type DepositArgs = {
  feePayer: web3.PublicKey;
  user: web3.PublicKey;
  userUsdcAta: web3.PublicKey;
  vaultUsdcAta: web3.PublicKey;
  shareMint: web3.PublicKey;
  userShareAta: web3.PublicKey;
  source: web3.PublicKey;
  mint: web3.PublicKey;
  destination: web3.PublicKey;
  authority: web3.PublicKey;
  owner: web3.PublicKey;
  wallet: web3.PublicKey;
  name: string;
  amount: bigint;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * User deposits USDC and receives vault shares pro-rata
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to deposit into
 * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[signer]` user: {@link PublicKey} The user making the deposit
 * 4. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
 * 5. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 6. `[writable]` share_mint: {@link Mint} Vault share mint
 * 7. `[writable, signer]` user_share_ata: {@link PublicKey} User's share token account
 * 8. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 9. `[writable]` source: {@link PublicKey} The source account.
 * 10. `[writable]` mint: {@link Mint} The token mint.
 * 11. `[writable]` destination: {@link PublicKey} The destination account.
 * 12. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
 * 13. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
 * 14. `[signer]` owner: {@link PublicKey} The mint's minting authority.
 * 15. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 16. `[]` token_program: {@link PublicKey} SPL Token program
 * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - amount: {@link BigInt} Amount of USDC to deposit
 */
export const depositBuilder = (
	args: DepositArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [vaultDepositorPubkey] = pda.deriveVaultDepositorPDA({
        vault: args.vault,
        user: args.user,
    }, _program.programId);
    const [assocTokenAccountPubkey] = pda.CslSplTokenPDAs.deriveAccountPDA({
        wallet: args.wallet,
        tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
        mint: args.mint,
    }, new web3.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"));

  return _program
    .methods
    .deposit(
      args.name,
      new BN(args.amount.toString()),
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      vaultDepositor: vaultDepositorPubkey,
      user: args.user,
      userUsdcAta: args.userUsdcAta,
      vaultUsdcAta: args.vaultUsdcAta,
      shareMint: args.shareMint,
      userShareAta: args.userShareAta,
      systemProgram: new web3.PublicKey("11111111111111111111111111111111"),
      source: args.source,
      mint: args.mint,
      destination: args.destination,
      authority: args.authority,
      assocTokenAccount: assocTokenAccountPubkey,
      owner: args.owner,
      wallet: args.wallet,
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * User deposits USDC and receives vault shares pro-rata
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to deposit into
 * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[signer]` user: {@link PublicKey} The user making the deposit
 * 4. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
 * 5. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 6. `[writable]` share_mint: {@link Mint} Vault share mint
 * 7. `[writable, signer]` user_share_ata: {@link PublicKey} User's share token account
 * 8. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 9. `[writable]` source: {@link PublicKey} The source account.
 * 10. `[writable]` mint: {@link Mint} The token mint.
 * 11. `[writable]` destination: {@link PublicKey} The destination account.
 * 12. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
 * 13. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
 * 14. `[signer]` owner: {@link PublicKey} The mint's minting authority.
 * 15. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 16. `[]` token_program: {@link PublicKey} SPL Token program
 * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - amount: {@link BigInt} Amount of USDC to deposit
 */
export const deposit = (
	args: DepositArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    depositBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * User deposits USDC and receives vault shares pro-rata
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to deposit into
 * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[signer]` user: {@link PublicKey} The user making the deposit
 * 4. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
 * 5. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 6. `[writable]` share_mint: {@link Mint} Vault share mint
 * 7. `[writable, signer]` user_share_ata: {@link PublicKey} User's share token account
 * 8. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 9. `[writable]` source: {@link PublicKey} The source account.
 * 10. `[writable]` mint: {@link Mint} The token mint.
 * 11. `[writable]` destination: {@link PublicKey} The destination account.
 * 12. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
 * 13. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
 * 14. `[signer]` owner: {@link PublicKey} The mint's minting authority.
 * 15. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 16. `[]` token_program: {@link PublicKey} SPL Token program
 * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - amount: {@link BigInt} Amount of USDC to deposit
 */
export const depositSendAndConfirm = async (
  args: Omit<DepositArgs, "feePayer" | "user" | "userShareAta" | "authority" | "owner"> & {
    signers: {
      feePayer: web3.Signer,
      user: web3.Signer,
      userShareAta: web3.Signer,
      authority: web3.Signer,
      owner: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return depositBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      user: args.signers.user.publicKey,
      userShareAta: args.signers.userShareAta.publicKey,
      authority: args.signers.authority.publicKey,
      owner: args.signers.owner.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.user, args.signers.userShareAta, args.signers.authority, args.signers.owner])
    .rpc();
}

export type RequestWithdrawArgs = {
  feePayer: web3.PublicKey;
  user: web3.PublicKey;
  name: string;
  shares: bigint;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Request withdrawal with timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault to withdraw from
 * 2. `[]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request account
 * 4. `[signer]` user: {@link PublicKey} The user requesting withdrawal
 * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - shares: {@link BigInt} Number of shares to withdraw
 */
export const requestWithdrawBuilder = (
	args: RequestWithdrawArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [vaultDepositorPubkey] = pda.deriveVaultDepositorPDA({
        vault: args.vault,
        user: args.user,
    }, _program.programId);
    const [withdrawRequestPubkey] = pda.deriveWithdrawRequestPDA({
        vault: args.vault,
        user: args.user,
    }, _program.programId);

  return _program
    .methods
    .requestWithdraw(
      args.name,
      new BN(args.shares.toString()),
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      vaultDepositor: vaultDepositorPubkey,
      withdrawRequest: withdrawRequestPubkey,
      user: args.user,
      systemProgram: new web3.PublicKey("11111111111111111111111111111111"),
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Request withdrawal with timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault to withdraw from
 * 2. `[]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request account
 * 4. `[signer]` user: {@link PublicKey} The user requesting withdrawal
 * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - shares: {@link BigInt} Number of shares to withdraw
 */
export const requestWithdraw = (
	args: RequestWithdrawArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    requestWithdrawBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Request withdrawal with timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault to withdraw from
 * 2. `[]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request account
 * 4. `[signer]` user: {@link PublicKey} The user requesting withdrawal
 * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - shares: {@link BigInt} Number of shares to withdraw
 */
export const requestWithdrawSendAndConfirm = async (
  args: Omit<RequestWithdrawArgs, "feePayer" | "user"> & {
    signers: {
      feePayer: web3.Signer,
      user: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return requestWithdrawBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      user: args.signers.user.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.user])
    .rpc();
}

export type CancelWithdrawRequestArgs = {
  feePayer: web3.PublicKey;
  user: web3.PublicKey;
  name: string;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Cancel a pending withdrawal request
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault the request belongs to
 * 2. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to cancel
 * 3. `[signer]` user: {@link PublicKey} The user canceling the request
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const cancelWithdrawRequestBuilder = (
	args: CancelWithdrawRequestArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [withdrawRequestPubkey] = pda.deriveWithdrawRequestPDA({
        vault: args.vault,
        user: args.user,
    }, _program.programId);

  return _program
    .methods
    .cancelWithdrawRequest(
      args.name,
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      withdrawRequest: withdrawRequestPubkey,
      user: args.user,
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Cancel a pending withdrawal request
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault the request belongs to
 * 2. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to cancel
 * 3. `[signer]` user: {@link PublicKey} The user canceling the request
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const cancelWithdrawRequest = (
	args: CancelWithdrawRequestArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    cancelWithdrawRequestBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Cancel a pending withdrawal request
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault the request belongs to
 * 2. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to cancel
 * 3. `[signer]` user: {@link PublicKey} The user canceling the request
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const cancelWithdrawRequestSendAndConfirm = async (
  args: Omit<CancelWithdrawRequestArgs, "feePayer" | "user"> & {
    signers: {
      feePayer: web3.Signer,
      user: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return cancelWithdrawRequestBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      user: args.signers.user.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.user])
    .rpc();
}

export type WithdrawArgs = {
  feePayer: web3.PublicKey;
  user: web3.PublicKey;
  userUsdcAta: web3.PublicKey;
  vaultUsdcAta: web3.PublicKey;
  shareMint: web3.PublicKey;
  userShareAta: web3.PublicKey;
  mint: web3.PublicKey;
  owner: web3.PublicKey;
  wallet: web3.PublicKey;
  source: web3.PublicKey;
  destination: web3.PublicKey;
  authority: web3.PublicKey;
  name: string;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Execute queued withdrawal after timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to withdraw from
 * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to execute
 * 4. `[signer]` user: {@link PublicKey} The user executing withdrawal
 * 5. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
 * 6. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 7. `[writable]` share_mint: {@link Mint} Vault share mint
 * 8. `[writable]` user_share_ata: {@link PublicKey} User's share token account
 * 9. `[writable]` account: {@link Account} The account to burn from.
 * 10. `[writable]` mint: {@link Mint} The token mint.
 * 11. `[signer]` owner: {@link PublicKey} The account's owner/delegate.
 * 12. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 13. `[]` token_program: {@link PublicKey} SPL Token program
 * 14. `[writable]` source: {@link PublicKey} The source account.
 * 15. `[writable]` destination: {@link PublicKey} The destination account.
 * 16. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
 * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const withdrawBuilder = (
	args: WithdrawArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [vaultDepositorPubkey] = pda.deriveVaultDepositorPDA({
        vault: args.vault,
        user: args.user,
    }, _program.programId);
    const [withdrawRequestPubkey] = pda.deriveWithdrawRequestPDA({
        vault: args.vault,
        user: args.user,
    }, _program.programId);
    const [accountPubkey] = pda.CslSplTokenPDAs.deriveAccountPDA({
        wallet: args.wallet,
        tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
        mint: args.mint,
    }, new web3.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"));

  return _program
    .methods
    .withdraw(
      args.name,
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      vaultDepositor: vaultDepositorPubkey,
      withdrawRequest: withdrawRequestPubkey,
      user: args.user,
      userUsdcAta: args.userUsdcAta,
      vaultUsdcAta: args.vaultUsdcAta,
      shareMint: args.shareMint,
      userShareAta: args.userShareAta,
      account: accountPubkey,
      mint: args.mint,
      owner: args.owner,
      wallet: args.wallet,
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
      source: args.source,
      destination: args.destination,
      authority: args.authority,
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Execute queued withdrawal after timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to withdraw from
 * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to execute
 * 4. `[signer]` user: {@link PublicKey} The user executing withdrawal
 * 5. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
 * 6. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 7. `[writable]` share_mint: {@link Mint} Vault share mint
 * 8. `[writable]` user_share_ata: {@link PublicKey} User's share token account
 * 9. `[writable]` account: {@link Account} The account to burn from.
 * 10. `[writable]` mint: {@link Mint} The token mint.
 * 11. `[signer]` owner: {@link PublicKey} The account's owner/delegate.
 * 12. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 13. `[]` token_program: {@link PublicKey} SPL Token program
 * 14. `[writable]` source: {@link PublicKey} The source account.
 * 15. `[writable]` destination: {@link PublicKey} The destination account.
 * 16. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
 * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const withdraw = (
	args: WithdrawArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    withdrawBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Execute queued withdrawal after timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to withdraw from
 * 2. `[writable]` vault_depositor: {@link VaultDepositor} User's depositor account
 * 3. `[writable]` withdraw_request: {@link WithdrawRequest} Withdrawal request to execute
 * 4. `[signer]` user: {@link PublicKey} The user executing withdrawal
 * 5. `[writable]` user_usdc_ata: {@link PublicKey} User's USDC token account
 * 6. `[writable]` vault_usdc_ata: {@link PublicKey} Vault's USDC token account
 * 7. `[writable]` share_mint: {@link Mint} Vault share mint
 * 8. `[writable]` user_share_ata: {@link PublicKey} User's share token account
 * 9. `[writable]` account: {@link Account} The account to burn from.
 * 10. `[writable]` mint: {@link Mint} The token mint.
 * 11. `[signer]` owner: {@link PublicKey} The account's owner/delegate.
 * 12. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 13. `[]` token_program: {@link PublicKey} SPL Token program
 * 14. `[writable]` source: {@link PublicKey} The source account.
 * 15. `[writable]` destination: {@link PublicKey} The destination account.
 * 16. `[signer]` authority: {@link PublicKey} The source account's owner/delegate.
 * 17. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const withdrawSendAndConfirm = async (
  args: Omit<WithdrawArgs, "feePayer" | "user" | "owner" | "authority"> & {
    signers: {
      feePayer: web3.Signer,
      user: web3.Signer,
      owner: web3.Signer,
      authority: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return withdrawBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      user: args.signers.user.publicKey,
      owner: args.signers.owner.publicKey,
      authority: args.signers.authority.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.user, args.signers.owner, args.signers.authority])
    .rpc();
}

export type StartFeeUpdateArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  name: string;
  newManagementFeeBps: number;
  newProfitShareBps: number;
  newHurdleRateBps: number;
  timelockPeriod: bigint;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Stage new fee parameters with timelock
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault to update fees for
 * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update staging account
 * 3. `[signer]` manager: {@link PublicKey} Vault manager account
 * 4. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_management_fee_bps: {@link number} New management fee in basis points
 * - new_profit_share_bps: {@link number} New profit share fee in basis points
 * - new_hurdle_rate_bps: {@link number} New hurdle rate in basis points
 * - timelock_period: {@link BigInt} Timelock period in seconds
 */
export const startFeeUpdateBuilder = (
	args: StartFeeUpdateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [feeUpdatePubkey] = pda.deriveFeeUpdatePDA({
        vault: args.vault,
    }, _program.programId);

  return _program
    .methods
    .startFeeUpdate(
      args.name,
      args.newManagementFeeBps,
      args.newProfitShareBps,
      args.newHurdleRateBps,
      new BN(args.timelockPeriod.toString()),
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      feeUpdate: feeUpdatePubkey,
      manager: args.manager,
      systemProgram: new web3.PublicKey("11111111111111111111111111111111"),
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Stage new fee parameters with timelock
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault to update fees for
 * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update staging account
 * 3. `[signer]` manager: {@link PublicKey} Vault manager account
 * 4. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_management_fee_bps: {@link number} New management fee in basis points
 * - new_profit_share_bps: {@link number} New profit share fee in basis points
 * - new_hurdle_rate_bps: {@link number} New hurdle rate in basis points
 * - timelock_period: {@link BigInt} Timelock period in seconds
 */
export const startFeeUpdate = (
	args: StartFeeUpdateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    startFeeUpdateBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Stage new fee parameters with timelock
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[]` vault: {@link Vault} The vault to update fees for
 * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update staging account
 * 3. `[signer]` manager: {@link PublicKey} Vault manager account
 * 4. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_management_fee_bps: {@link number} New management fee in basis points
 * - new_profit_share_bps: {@link number} New profit share fee in basis points
 * - new_hurdle_rate_bps: {@link number} New hurdle rate in basis points
 * - timelock_period: {@link BigInt} Timelock period in seconds
 */
export const startFeeUpdateSendAndConfirm = async (
  args: Omit<StartFeeUpdateArgs, "feePayer" | "manager"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return startFeeUpdateBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager])
    .rpc();
}

export type ApplyFeeUpdateArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  name: string;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Apply staged fee update after timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update to apply
 * 3. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const applyFeeUpdateBuilder = (
	args: ApplyFeeUpdateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [feeUpdatePubkey] = pda.deriveFeeUpdatePDA({
        vault: args.vault,
    }, _program.programId);

  return _program
    .methods
    .applyFeeUpdate(
      args.name,
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      feeUpdate: feeUpdatePubkey,
      manager: args.manager,
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Apply staged fee update after timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update to apply
 * 3. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const applyFeeUpdate = (
	args: ApplyFeeUpdateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    applyFeeUpdateBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Apply staged fee update after timelock period
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[writable]` fee_update: {@link FeeUpdate} Fee update to apply
 * 3. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const applyFeeUpdateSendAndConfirm = async (
  args: Omit<ApplyFeeUpdateArgs, "feePayer" | "manager"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return applyFeeUpdateBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager])
    .rpc();
}

export type UpdateDelegateArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  name: string;
  newDelegate: web3.PublicKey | undefined;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Set or change the Drift trading delegate
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_delegate: {@link PublicKey | undefined} New delegate pubkey (None to remove)
 */
export const updateDelegateBuilder = (
	args: UpdateDelegateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);

  return _program
    .methods
    .updateDelegate(
      args.name,
      args.newDelegate,
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      manager: args.manager,
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Set or change the Drift trading delegate
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_delegate: {@link PublicKey | undefined} New delegate pubkey (None to remove)
 */
export const updateDelegate = (
	args: UpdateDelegateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    updateDelegateBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Set or change the Drift trading delegate
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_delegate: {@link PublicKey | undefined} New delegate pubkey (None to remove)
 */
export const updateDelegateSendAndConfirm = async (
  args: Omit<UpdateDelegateArgs, "feePayer" | "manager"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return updateDelegateBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager])
    .rpc();
}

export type UpdateVaultArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  name: string;
  newMinDepositAmount: bigint | undefined;
  newRedeemPeriod: bigint | undefined;
  newPaused: boolean | undefined;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Update vault parameters (manager only)
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_min_deposit_amount: {@link BigInt | undefined} New minimum deposit amount
 * - new_redeem_period: {@link BigInt | undefined} New withdrawal timelock period
 * - new_paused: {@link boolean | undefined} New paused status
 */
export const updateVaultBuilder = (
	args: UpdateVaultArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);

  return _program
    .methods
    .updateVault(
      args.name,
      args.newMinDepositAmount ? new BN(args.newMinDepositAmount.toString()) : undefined,
      args.newRedeemPeriod ? new BN(args.newRedeemPeriod.toString()) : undefined,
      args.newPaused,
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      manager: args.manager,
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Update vault parameters (manager only)
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_min_deposit_amount: {@link BigInt | undefined} New minimum deposit amount
 * - new_redeem_period: {@link BigInt | undefined} New withdrawal timelock period
 * - new_paused: {@link boolean | undefined} New paused status
 */
export const updateVault = (
	args: UpdateVaultArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    updateVaultBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Update vault parameters (manager only)
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to update
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_min_deposit_amount: {@link BigInt | undefined} New minimum deposit amount
 * - new_redeem_period: {@link BigInt | undefined} New withdrawal timelock period
 * - new_paused: {@link boolean | undefined} New paused status
 */
export const updateVaultSendAndConfirm = async (
  args: Omit<UpdateVaultArgs, "feePayer" | "manager"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return updateVaultBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager])
    .rpc();
}

export type ApplyProfitShareArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  shareMint: web3.PublicKey;
  feeCollectorShareAta: web3.PublicKey;
  mint: web3.PublicKey;
  owner: web3.PublicKey;
  wallet: web3.PublicKey;
  name: string;
  currentEquity: bigint;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Crystallize profit share vs high watermark and mint manager shares
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to apply profit share for
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 * 3. `[writable]` share_mint: {@link Mint} Vault share mint
 * 4. `[writable, signer]` fee_collector_share_ata: {@link PublicKey} Fee collector's share token account
 * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 6. `[writable]` mint: {@link Mint} The mint.
 * 7. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
 * 8. `[signer]` owner: {@link PublicKey} The mint's minting authority.
 * 9. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 10. `[]` token_program: {@link PublicKey} SPL Token program
 * 11. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - current_equity: {@link BigInt} Current vault equity value
 */
export const applyProfitShareBuilder = (
	args: ApplyProfitShareArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);
    const [assocTokenAccountPubkey] = pda.CslSplTokenPDAs.deriveAccountPDA({
        wallet: args.wallet,
        tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
        mint: args.mint,
    }, new web3.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"));

  return _program
    .methods
    .applyProfitShare(
      args.name,
      new BN(args.currentEquity.toString()),
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      manager: args.manager,
      shareMint: args.shareMint,
      feeCollectorShareAta: args.feeCollectorShareAta,
      systemProgram: new web3.PublicKey("11111111111111111111111111111111"),
      mint: args.mint,
      assocTokenAccount: assocTokenAccountPubkey,
      owner: args.owner,
      wallet: args.wallet,
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
      tokenProgram: new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Crystallize profit share vs high watermark and mint manager shares
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to apply profit share for
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 * 3. `[writable]` share_mint: {@link Mint} Vault share mint
 * 4. `[writable, signer]` fee_collector_share_ata: {@link PublicKey} Fee collector's share token account
 * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 6. `[writable]` mint: {@link Mint} The mint.
 * 7. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
 * 8. `[signer]` owner: {@link PublicKey} The mint's minting authority.
 * 9. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 10. `[]` token_program: {@link PublicKey} SPL Token program
 * 11. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - current_equity: {@link BigInt} Current vault equity value
 */
export const applyProfitShare = (
	args: ApplyProfitShareArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    applyProfitShareBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Crystallize profit share vs high watermark and mint manager shares
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to apply profit share for
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 * 3. `[writable]` share_mint: {@link Mint} Vault share mint
 * 4. `[writable, signer]` fee_collector_share_ata: {@link PublicKey} Fee collector's share token account
 * 5. `[]` system_program: {@link PublicKey} Auto-generated, for account initialization
 * 6. `[writable]` mint: {@link Mint} The mint.
 * 7. `[writable]` assoc_token_account: {@link Account} The account to mint tokens to.
 * 8. `[signer]` owner: {@link PublicKey} The mint's minting authority.
 * 9. `[]` wallet: {@link PublicKey} Wallet address for the new associated token account
 * 10. `[]` token_program: {@link PublicKey} SPL Token program
 * 11. `[]` token_program: {@link PublicKey} Auto-generated, TokenProgram
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - current_equity: {@link BigInt} Current vault equity value
 */
export const applyProfitShareSendAndConfirm = async (
  args: Omit<ApplyProfitShareArgs, "feePayer" | "manager" | "feeCollectorShareAta" | "owner"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
      feeCollectorShareAta: web3.Signer,
      owner: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return applyProfitShareBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
      feeCollectorShareAta: args.signers.feeCollectorShareAta.publicKey,
      owner: args.signers.owner.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager, args.signers.feeCollectorShareAta, args.signers.owner])
    .rpc();
}

export type ApplyRebaseArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  name: string;
  newTotalShares: bigint;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Adjust total shares when equity is much smaller than shares
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to rebase
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_total_shares: {@link BigInt} New total shares amount
 */
export const applyRebaseBuilder = (
	args: ApplyRebaseArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);

  return _program
    .methods
    .applyRebase(
      args.name,
      new BN(args.newTotalShares.toString()),
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      manager: args.manager,
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Adjust total shares when equity is much smaller than shares
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to rebase
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_total_shares: {@link BigInt} New total shares amount
 */
export const applyRebase = (
	args: ApplyRebaseArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    applyRebaseBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Adjust total shares when equity is much smaller than shares
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to rebase
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 * - new_total_shares: {@link BigInt} New total shares amount
 */
export const applyRebaseSendAndConfirm = async (
  args: Omit<ApplyRebaseArgs, "feePayer" | "manager"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return applyRebaseBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager])
    .rpc();
}

export type LiquidateArgs = {
  feePayer: web3.PublicKey;
  manager: web3.PublicKey;
  name: string;
};

/**
 * ### Returns a {@link MethodsBuilder}
 * Mark vault as in liquidation mode
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to liquidate
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const liquidateBuilder = (
	args: LiquidateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): MethodsBuilder<SentiAiVault, never> => {
    const [vaultPubkey] = pda.deriveVaultPDA({
        name: args.name,
    }, _program.programId);

  return _program
    .methods
    .liquidate(
      args.name,
    )
    .accountsStrict({
      feePayer: args.feePayer,
      vault: vaultPubkey,
      manager: args.manager,
    })
    .remainingAccounts(remainingAccounts);
};

/**
 * ### Returns a {@link web3.TransactionInstruction}
 * Mark vault as in liquidation mode
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to liquidate
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const liquidate = (
	args: LiquidateArgs,
	remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionInstruction> =>
    liquidateBuilder(args, remainingAccounts).instruction();

/**
 * ### Returns a {@link web3.TransactionSignature}
 * Mark vault as in liquidation mode
 *
 * Accounts:
 * 0. `[writable, signer]` fee_payer: {@link PublicKey} 
 * 1. `[writable]` vault: {@link Vault} The vault to liquidate
 * 2. `[signer]` manager: {@link PublicKey} Vault manager account
 *
 * Data:
 * - name: {@link string} Vault name for PDA derivation
 */
export const liquidateSendAndConfirm = async (
  args: Omit<LiquidateArgs, "feePayer" | "manager"> & {
    signers: {
      feePayer: web3.Signer,
      manager: web3.Signer,
    },
  },
  remainingAccounts: Array<web3.AccountMeta> = [],
): Promise<web3.TransactionSignature> => {
  const preInstructions: Array<web3.TransactionInstruction> = [];


  return liquidateBuilder({
      ...args,
      feePayer: args.signers.feePayer.publicKey,
      manager: args.signers.manager.publicKey,
    }, remainingAccounts)
    .preInstructions(preInstructions)
    .signers([args.signers.feePayer, args.signers.manager])
    .rpc();
}

// Getters

export const getVault = (
    publicKey: web3.PublicKey,
    commitment?: web3.Commitment
): Promise<IdlAccounts<SentiAiVault>["vault"]> => _program.account.vault.fetch(publicKey, commitment);

export const getVaultDepositor = (
    publicKey: web3.PublicKey,
    commitment?: web3.Commitment
): Promise<IdlAccounts<SentiAiVault>["vaultDepositor"]> => _program.account.vaultDepositor.fetch(publicKey, commitment);

export const getWithdrawRequest = (
    publicKey: web3.PublicKey,
    commitment?: web3.Commitment
): Promise<IdlAccounts<SentiAiVault>["withdrawRequest"]> => _program.account.withdrawRequest.fetch(publicKey, commitment);

export const getFeeUpdate = (
    publicKey: web3.PublicKey,
    commitment?: web3.Commitment
): Promise<IdlAccounts<SentiAiVault>["feeUpdate"]> => _program.account.feeUpdate.fetch(publicKey, commitment);
